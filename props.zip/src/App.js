import React from "react";
import "./App.css";
import PersonCard from "./components/PersonCard";

function App() {
  return (
    <div className="App">
      <PersonCard
        firstName={"Ken"}
        lastName={"Griffey Jr"}
        age={"31"}
        hair={"black"}
      />
      <PersonCard
        firstName={"Julio"}
        lastName={"Rodriguez"}
        age={"21"}
        hair={"black"}
      />
      <PersonCard
        firstName={"Felix"}
        lastName={"Hernandez"}
        age={"34"}
        hair={"dyed yellow"}
      />
      <PersonCard
        firstName={"Ichiro"}
        lastName={"Suzuki"}
        age={"47"}
        hair={"black"}
      />
    </div>
  );
}

export default App;
