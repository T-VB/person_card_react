import React from "react";

const PersonCard = (props) => {
  const { firstName, lastName, hair } = props;
  return (
    <div>
      <h2>
        {lastName}, {firstName}
      </h2>
      <h4>Age: {props.age}</h4>
      <h4>Hair: {hair}</h4>
    </div>
  );
};

export default PersonCard;
